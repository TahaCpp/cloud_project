import React from "react";

const Error = () => {
  return (
    <div style={{ textAlign: "center", margin: "100px auto" }}>
      <img src="https://svgshare.com/i/Tks.svg" alt="404"></img>
    </div>
  );
};

export default Error;
